# Decision Randomizer — MVP

One-time-purchase Android utility. Type 2+ options, shuffle, get an answer. No backend, no account, no subscription.

## What's built

- **Data layer:** `DecisionList` model + `DecisionRepository` (Jetpack DataStore, fully local, JSON-serialized)
- **3 screens:** Home (list of lists) → Editor (name + items) → Result (shuffle/save/share)
- **Glance home screen widget:** shows your most recent list, tap "Shuffle" to reshuffle without opening the app
- **Play Billing:** one-time non-consumable purchase (`unlock_unlimited_lists`) gating the free 1-list limit

## Before you can run it

1. **Open in Android Studio** (Koala+ recommended) as an existing project — point it at this folder.
2. **Add a launcher icon** — `mipmap/ic_launcher` is referenced in the manifest but not included. Use Android Studio's Image Asset tool (right-click `res` → New → Image Asset).
3. **Play Console setup** (required before billing will work):
   - Create the app listing
   - Add an in-app product with ID exactly `unlock_unlimited_lists`, one-time, priced at $2.99
   - You must upload a signed build to an internal testing track before billing calls will return real product details — it returns empty in debug builds installed via USB until that's done.
4. **Gradle sync** will pull all dependencies (Compose, Glance, DataStore, Billing) — no manual setup needed beyond Android Studio + JDK 17.

## Known gaps (intentional, by design — see scope notes)

- Widget always shows the *most recently created* list, not a per-widget picker. Multi-instance widget configuration (long-press → choose list) is a fast v1.1 add if usage data shows people want >1 list pinned.
- No list reordering/sorting on Home — fine at small list counts.
- No onboarding/tutorial screens — the empty state on Home explains the single action needed.

## Build order if you're continuing this yourself

1. Test data layer + CRUD flow first (Home/Editor/Result) without worrying about billing or widget
2. Get billing working end-to-end on an internal test track
3. Wire and test the widget last — it's the most device/launcher-specific piece and easiest to debug once the core data flow is solid

## File map

```
app/src/main/java/com/provyk/decisionrandomizer/
├── MainActivity.kt              # NavHost wiring all screens
├── data/
│   ├── DecisionList.kt          # model
│   └── DecisionRepository.kt    # DataStore persistence
├── billing/
│   └── BillingManager.kt        # Play Billing, one-time purchase
├── ui/
│   ├── DecisionViewModel.kt
│   ├── theme/Theme.kt
│   └── screens/
│       ├── HomeScreen.kt
│       ├── EditorScreen.kt
│       ├── ResultScreen.kt
│       └── PaywallScreen.kt
└── widget/
    ├── DecisionWidget.kt        # Glance widget UI
    ├── DecisionWidgetReceiver.kt
    └── ShuffleAction.kt         # tap-to-shuffle from widget
```
