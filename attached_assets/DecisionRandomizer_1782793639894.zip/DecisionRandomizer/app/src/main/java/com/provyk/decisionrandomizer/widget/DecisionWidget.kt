package com.provyk.decisionrandomizer.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionParametersOf
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.*
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import com.provyk.decisionrandomizer.data.DecisionRepository
import kotlinx.coroutines.flow.first

class DecisionWidget : GlanceAppWidget() {

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val repository = DecisionRepository(context)
        // Widget shows the most recently created list — simplest v1 behavior,
        // no per-widget list picker yet (that's a v1.1 feature).
        val lists = repository.lists.first()
        val list = lists.maxByOrNull { it.createdAt }

        provideContent {
            Column(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(Color(0xFFFFFFFF))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (list == null || list.items.isEmpty()) {
                    Text(
                        text = "Open the app to create a list",
                        style = TextStyle(fontSize = 13.sp, color = ColorProvider(Color(0xFF333333)))
                    )
                } else {
                    Text(
                        text = list.name,
                        style = TextStyle(fontSize = 12.sp, color = ColorProvider(Color(0xFF888888)))
                    )
                    Spacer(GlanceModifier.height(6.dp))
                    Text(
                        text = list.lastResult ?: "Tap to decide",
                        style = TextStyle(fontSize = 20.sp, color = ColorProvider(Color(0xFF222222)))
                    )
                    Spacer(GlanceModifier.height(10.dp))
                    Box(
                        modifier = GlanceModifier
                            .background(Color(0xFF5B6CFF))
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .clickable(
                                actionRunCallback<ShuffleAction>(
                                    actionParametersOf(ShuffleAction.listIdKey to list.id)
                                )
                            )
                    ) {
                        Text(
                            text = "Shuffle",
                            style = TextStyle(fontSize = 14.sp, color = ColorProvider(Color(0xFFFFFFFF)))
                        )
                    }
                }
            }
        }
    }
}
