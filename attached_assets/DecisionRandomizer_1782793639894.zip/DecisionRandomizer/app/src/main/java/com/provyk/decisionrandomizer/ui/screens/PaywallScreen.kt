package com.provyk.decisionrandomizer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.provyk.decisionrandomizer.ui.DecisionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaywallScreen(viewModel: DecisionViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    Scaffold(topBar = { TopAppBar(title = { Text("Unlock Unlimited") }) }) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Free plan is limited to 1 list.", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Text(
                "Unlock unlimited lists + the home screen widget with a one-time purchase. No subscription.",
                style = MaterialTheme.typography.bodyMedium,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))
            Button(onClick = {
                (context as? android.app.Activity)?.let { viewModel.billing.launchPurchase(it) }
            }) {
                Text("Unlock — $2.99")
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onBack) { Text("Maybe later") }
        }
    }
}
