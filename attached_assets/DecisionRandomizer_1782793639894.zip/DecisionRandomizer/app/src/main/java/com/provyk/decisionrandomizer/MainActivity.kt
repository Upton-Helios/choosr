package com.provyk.decisionrandomizer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.provyk.decisionrandomizer.ui.DecisionViewModel
import com.provyk.decisionrandomizer.ui.screens.*
import com.provyk.decisionrandomizer.ui.theme.DecisionRandomizerTheme

class MainActivity : ComponentActivity() {

    private val viewModel: DecisionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DecisionRandomizerTheme {
                val navController = rememberNavController()
                val lists by viewModel.lists.collectAsState()

                NavHost(navController = navController, startDestination = "home") {

                    composable("home") {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenList = { id -> navController.navigate("result/$id") },
                            onCreateNew = { navController.navigate("editor") },
                            onShowPaywall = { navController.navigate("paywall") }
                        )
                    }

                    composable("editor") {
                        EditorScreen(
                            viewModel = viewModel,
                            existing = null,
                            onBack = { navController.popBackStack() },
                            onSaved = { id ->
                                navController.popBackStack()
                                navController.navigate("result/$id")
                            }
                        )
                    }

                    composable(
                        "editor/{listId}",
                        arguments = listOf(navArgument("listId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val listId = backStackEntry.arguments?.getString("listId")
                        val existing = lists.find { it.id == listId }
                        EditorScreen(
                            viewModel = viewModel,
                            existing = existing,
                            onBack = { navController.popBackStack() },
                            onSaved = { id ->
                                navController.popBackStack()
                                navController.navigate("result/$id") {
                                    popUpTo("home")
                                }
                            }
                        )
                    }

                    composable(
                        "result/{listId}",
                        arguments = listOf(navArgument("listId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val listId = backStackEntry.arguments?.getString("listId")
                        val list = lists.find { it.id == listId }
                        if (list != null) {
                            ResultScreen(
                                viewModel = viewModel,
                                list = list,
                                onBack = { navController.popBackStack() },
                                onEdit = { navController.navigate("editor/${list.id}") }
                            )
                        }
                    }

                    composable("paywall") {
                        PaywallScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }
}
