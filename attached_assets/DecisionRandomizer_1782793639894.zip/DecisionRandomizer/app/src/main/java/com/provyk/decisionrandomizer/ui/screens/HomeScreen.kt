package com.provyk.decisionrandomizer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.provyk.decisionrandomizer.data.DecisionList
import com.provyk.decisionrandomizer.ui.DecisionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DecisionViewModel,
    onOpenList: (String) -> Unit,
    onCreateNew: () -> Unit,
    onShowPaywall: () -> Unit
) {
    val lists by viewModel.lists.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Decision Randomizer") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                if (viewModel.isAtFreeLimit()) onShowPaywall() else onCreateNew()
            }) {
                Icon(Icons.Default.Add, contentDescription = "New list")
            }
        }
    ) { padding ->
        if (lists.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No lists yet", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Tap + to create your first decision list", style = MaterialTheme.typography.bodyMedium)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(lists, key = { it.id }) { list ->
                    DecisionListCard(
                        list = list,
                        onClick = { onOpenList(list.id) },
                        onDelete = { viewModel.deleteList(list.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun DecisionListCard(list: DecisionList, onClick: () -> Unit, onDelete: () -> Unit) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(list.name, style = MaterialTheme.typography.titleMedium)
                Text(
                    "${list.items.size} options" + (list.lastResult?.let { "  •  Last: $it" } ?: ""),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete list")
            }
        }
    }
}
