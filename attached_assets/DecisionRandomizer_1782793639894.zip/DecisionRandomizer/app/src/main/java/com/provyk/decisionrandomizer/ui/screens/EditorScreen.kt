package com.provyk.decisionrandomizer.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.provyk.decisionrandomizer.data.DecisionList
import com.provyk.decisionrandomizer.ui.DecisionViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(
    viewModel: DecisionViewModel,
    existing: DecisionList?,
    onBack: () -> Unit,
    onSaved: (String) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var items by remember { mutableStateOf(existing?.items ?: emptyList()) }
    var newItem by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (existing == null) "New List" else "Edit List") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("List name (e.g. Dinner Tonight)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = newItem,
                    onValueChange = { newItem = it },
                    label = { Text("Add an option") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (newItem.isNotBlank()) {
                        items = items + newItem.trim()
                        newItem = ""
                    }
                }) { Text("Add") }
            }

            Spacer(Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(items) { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item, style = MaterialTheme.typography.bodyLarge)
                        IconButton(onClick = { items = items.filterNot { it == item } }) {
                            Icon(Icons.Default.Close, contentDescription = "Remove")
                        }
                    }
                    Divider()
                }
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = {
                    val list = (existing ?: DecisionList(name = name)).copy(
                        name = name.ifBlank { "Untitled" },
                        items = items
                    )
                    viewModel.saveList(list)
                    onSaved(list.id)
                },
                enabled = name.isNotBlank() && items.size >= 2,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Save List")
            }

            if (items.size < 2) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "Add at least 2 options to save",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
    }
}
