package com.provyk.decisionrandomizer.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "decision_lists_store")

class DecisionRepository(private val context: Context) {

    private val listsKey = stringPreferencesKey("lists_json")
    private val json = Json { ignoreUnknownKeys = true }

    val lists: Flow<List<DecisionList>> = context.dataStore.data.map { prefs ->
        val raw = prefs[listsKey] ?: return@map emptyList()
        runCatching { json.decodeFromString<List<DecisionList>>(raw) }.getOrDefault(emptyList())
    }

    suspend fun saveAll(lists: List<DecisionList>) {
        context.dataStore.edit { prefs ->
            prefs[listsKey] = json.encodeToString(lists)
        }
    }

    suspend fun upsert(list: DecisionList) {
        val current = currentSnapshot()
        val updated = current.filterNot { it.id == list.id } + list
        saveAll(updated)
    }

    suspend fun delete(id: String) {
        val current = currentSnapshot()
        saveAll(current.filterNot { it.id == id })
    }

    private suspend fun currentSnapshot(): List<DecisionList> = lists.first()
}
