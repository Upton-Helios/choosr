package com.provyk.decisionrandomizer.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.provyk.decisionrandomizer.billing.BillingManager
import com.provyk.decisionrandomizer.data.DecisionList
import com.provyk.decisionrandomizer.data.DecisionRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DecisionViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = DecisionRepository(app)
    val billing = BillingManager(app)

    val lists: StateFlow<List<DecisionList>> = repository.lists.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun isAtFreeLimit(): Boolean =
        !billing.isUnlocked.value && lists.value.size >= BillingManager.FREE_LIST_LIMIT

    fun saveList(list: DecisionList) = viewModelScope.launch {
        repository.upsert(list)
    }

    fun deleteList(id: String) = viewModelScope.launch {
        repository.delete(id)
    }

    fun shuffle(list: DecisionList): DecisionList {
        if (list.items.isEmpty()) return list
        val result = list.items.random()
        val updated = list.copy(lastResult = result)
        saveList(updated)
        return updated
    }
}
