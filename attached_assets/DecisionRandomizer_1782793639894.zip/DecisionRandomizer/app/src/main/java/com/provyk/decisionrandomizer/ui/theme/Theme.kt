package com.provyk.decisionrandomizer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF5B6CFF)

private val LightColors = lightColorScheme(
    primary = Accent,
    secondary = Color(0xFFFF8A5B)
)

private val DarkColors = darkColorScheme(
    primary = Accent,
    secondary = Color(0xFFFF8A5B)
)

@Composable
fun DecisionRandomizerTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
