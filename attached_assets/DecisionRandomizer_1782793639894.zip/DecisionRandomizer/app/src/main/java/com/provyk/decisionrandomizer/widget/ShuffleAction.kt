package com.provyk.decisionrandomizer.widget

import android.content.Context
import androidx.glance.GlanceId
import androidx.glance.action.ActionParameters
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.update
import com.provyk.decisionrandomizer.data.DecisionRepository
import kotlinx.coroutines.flow.first

class ShuffleAction : ActionCallback {

    companion object {
        val listIdKey = ActionParameters.Key<String>("list_id")
    }

    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val listId = parameters[listIdKey] ?: return
        val repository = DecisionRepository(context)
        val list = repository.lists.first().find { it.id == listId } ?: return
        if (list.items.isEmpty()) return

        val result = list.items.random()
        repository.upsert(list.copy(lastResult = result))

        DecisionWidget().update(context, glanceId)
    }
}
