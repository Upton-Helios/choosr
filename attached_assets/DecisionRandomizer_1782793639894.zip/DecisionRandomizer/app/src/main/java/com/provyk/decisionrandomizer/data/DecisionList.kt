package com.provyk.decisionrandomizer.data

import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
data class DecisionList(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val items: List<String> = emptyList(),
    val lastResult: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
